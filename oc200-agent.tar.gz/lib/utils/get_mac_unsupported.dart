Future<String?> getClientMac() async => null;

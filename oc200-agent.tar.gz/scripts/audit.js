/**
 * Mangalam WiFi Zone – Project Audit Script
 * -----------------------------------------
 * ✔ Verifies critical files
 * ✔ Verifies folder structure
 * ✔ Verifies environment variables
 * ✔ Detects legacy / wrong-direction artifacts
 * ✔ Prints FINAL STATUS REPORT (machine + human readable)
 *
 * Usage:
 *   node scripts/audit.js
 */

import fs from "fs";
import path from "path";

const ROOT = process.cwd();

/* ---------- HELPERS ---------- */
function exists(p) {
  return fs.existsSync(path.join(ROOT, p));
}

function readEnv() {
  const envPath = path.join(ROOT, "server/.env");
  if (!fs.existsSync(envPath)) return {};
  const raw = fs.readFileSync(envPath, "utf8");
  const out = {};
  raw.split("\n").forEach(l => {
    l = l.trim();
    if (!l || l.startsWith("#")) return;
    const [k, ...v] = l.split("=");
    out[k] = v.join("=");
  });
  return out;
}

/* ---------- EXPECTATIONS ---------- */
const REQUIRED_FILES = [
  "server/index.js",
  "server/utils/db.js",
  "server/routes/device.routes.js",
  "server/routes/razorpay.routes.js",
  "server/services/oc200.service.js",
  "server/models/device.model.js",
  "scripts/audit.js",
  "scripts/repair.js"
];

const REQUIRED_FOLDERS = [
  "server",
  "server/routes",
  "server/services",
  "server/models",
  "scripts",
  "client",
  "web_client"
];

const REQUIRED_ENV = [
  "PORT",
  "MONGO_URI",
  "JWT_SECRET",
  "RAZORPAY_KEY",
  "RAZORPAY_SECRET",
  "OC200_URL",
  "OC200_CLIENT_ID",
  "OC200_CLIENT_SECRET",
  "OC200_USERNAME",
  "OC200_PASSWORD"
];

const LEGACY_RED_FLAGS = [
  "tsconfig.json",
  "project-doctor.ts",
  "full-audit.ts",
  "scripts/project-doctor.ts",
  "scripts/full-audit.ts",
  "coupon.pdf",
  "voucher.pdf"
];

/* ---------- AUDIT ---------- */
const report = {
  files_ok: [],
  files_missing: [],
  folders_ok: [],
  folders_missing: [],
  env_ok: [],
  env_missing: [],
  legacy_detected: [],
  ready_percent: 0
};

/* Files */
REQUIRED_FILES.forEach(f => {
  exists(f) ? report.files_ok.push(f) : report.files_missing.push(f);
});

/* Folders */
REQUIRED_FOLDERS.forEach(d => {
  exists(d) ? report.folders_ok.push(d) : report.folders_missing.push(d);
});

/* Env */
const ENV = readEnv();
REQUIRED_ENV.forEach(k => {
  ENV[k] ? report.env_ok.push(k) : report.env_missing.push(k);
});

/* Legacy detection */
LEGACY_RED_FLAGS.forEach(f => {
  if (exists(f)) report.legacy_detected.push(f);
});

/* Score */
const totalChecks =
  REQUIRED_FILES.length +
  REQUIRED_FOLDERS.length +
  REQUIRED_ENV.length;

const passedChecks =
  report.files_ok.length +
  report.folders_ok.length +
  report.env_ok.length;

report.ready_percent = Math.round((passedChecks / totalChecks) * 100);

/* ---------- OUTPUT ---------- */
console.log("\n================ PROJECT AUDIT REPORT ================\n");

console.log("✔ Files OK:", report.files_ok.length);
console.log("✖ Files Missing:", report.files_missing.length);
report.files_missing.forEach(f => console.log("   -", f));

console.log("\n✔ Folders OK:", report.folders_ok.length);
console.log("✖ Folders Missing:", report.folders_missing.length);
report.folders_missing.forEach(d => console.log("   -", d));

console.log("\n✔ ENV OK:", report.env_ok.length);
console.log("✖ ENV Missing:", report.env_missing.length);
report.env_missing.forEach(e => console.log("   -", e));

console.log("\n⚠ Legacy / Wrong-Direction Artifacts:", report.legacy_detected.length);
report.legacy_detected.forEach(l => console.log("   -", l));

console.log("\n------------------------------------------------------");
console.log("PROJECT COMPLETION:", report.ready_percent + "%");
console.log("------------------------------------------------------\n");

/* Exit code logic */
if (
  report.files_missing.length ||
  report.folders_missing.length ||
  report.env_missing.length
) {
  console.log("STATUS: ❌ NOT READY — REPAIR REQUIRED\n");
  process.exit(1);
} else {
  console.log("STATUS: ✅ STRUCTURALLY READY\n");
  process.exit(0);
}
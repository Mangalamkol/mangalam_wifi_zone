const ADMIN = {
  SYSTEM: true,
  PAYMENT: true,
  WHATSAPP: true,
  COUPON: true
};

export default ADMIN;
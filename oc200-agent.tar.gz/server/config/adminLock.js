export const ADMIN_LOCK = {
  LIVE_MODE: true,
  ALLOW_CONFIG_CHANGE: false,
  ALLOW_KEY_EDIT: false,
  ALLOW_DB_CHANGE: false,
  ALLOW_PLAN_DELETE: false,
  ALLOW_COUPON_RESET: false
};

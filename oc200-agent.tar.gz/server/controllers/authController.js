exports.registerUser = async (req, res) => {
  res.json({ message: "Test register working" });
};

exports.loginUser = async (req, res) => {
  res.json({ message: "Test login working" });
};

exports.registerUser = async (req, res) => {
  res.json({ message: "Register API working" });
};

exports.loginUser = async (req, res) => {
  res.json({ message: "Login API working" });
};

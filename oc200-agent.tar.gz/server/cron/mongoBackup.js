const backupDB = require('../utils/backup.js');

backupDB();

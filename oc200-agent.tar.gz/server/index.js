import { connectDB } from "./utils/db.js";
import express from "express";
import cors from "cors";
import razorpayRoutes from "./routes/razorpay.routes.js";
import webhookRoutes from "./routes/webhook.js";
import "./jobs/session.job.js";

const app = express();

// Capture the raw body for webhook verification
app.use((req, res, next) => {
  req.rawBody = "";
  req.on("data", (chunk) => (req.rawBody += chunk.toString()));
  next();
});

app.use(cors());
app.use(express.json());

app.use("/api/v1/razorpay", razorpayRoutes);
app.use("/api/v1/webhook", webhookRoutes);

const PORT = process.env.PORT || 3000;

async function main() {
  await connectDB();
  app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });
}

main().catch((err) => {
  console.error("Error starting server:", err);
  process.exit(1);
});

import mongoose from "mongoose";

const SessionLogSchema = new mongoose.Schema({
  mac: String,
  planId: String,
  startAt: Date,
  expireAt: Date,
  active: Boolean
});

export default mongoose.model("SessionLog", SessionLogSchema);

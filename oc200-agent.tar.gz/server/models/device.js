import mongoose from 'mongoose';

const deviceSchema = new mongoose.Schema({
    macAddress: {
        type: String,
        required: true,
        unique: true
    },
    sessionId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Session',
        required: true
    },
    // Add other fields for your device as needed, e.g., deviceName, lastSeen
});

export default mongoose.model('Device', deviceSchema);

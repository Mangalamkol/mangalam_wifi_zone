//Boilerplate for server/models/device.model.js

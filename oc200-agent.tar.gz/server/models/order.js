import mongoose from 'mongoose';

const orderSchema = new mongoose.Schema({
    // Define your order schema here
});

export default mongoose.model('Order', orderSchema);

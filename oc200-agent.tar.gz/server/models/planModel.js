import mongoose from "mongoose";

const planSchema = new mongoose.Schema({
  id: String,
  name: String,
  duration: Number,
  price: Number,
  maxDevices: Number,
}, { timestamps: true });

export default mongoose.model("Plan", planSchema);
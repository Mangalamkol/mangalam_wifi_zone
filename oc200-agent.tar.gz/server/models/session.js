import mongoose from 'mongoose';

const sessionSchema = new mongoose.Schema({
    paymentId: {
        type: String,
        required: true
    },
    // Add other fields for your session as needed, e.g., userId, startTime, endTime
});

export default mongoose.model('Session', sessionSchema);

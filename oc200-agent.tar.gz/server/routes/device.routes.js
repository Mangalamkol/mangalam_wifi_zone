//Boilerplate for server/routes/device.routes.js

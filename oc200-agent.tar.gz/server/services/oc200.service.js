//Boilerplate for server/services/oc200.service.js

import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config({ path: './server/.env' });

const oc200Client = axios.create({
  baseURL: process.env.OC200_URL,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
  timeout: 10000, // 10s timeout
});

let token = null; // In-memory token storage

// --- Authentication ---
export const login = async () => {
  try {
    if (token) return token;
    const res = await oc200Client.post('/login', {
      username: process.env.OC200_USERNAME,
      password: process.env.OC200_PASSWORD,
    });
    token = res.data.result.token;
    return token;
  } catch (err) {
    console.error('OC200 Login Error:', err.message);
    token = null; // Clear token on failure
    throw new Error('Could not authenticate with OC200 controller');
  }
};

export const logout = async () => {
  try {
    if (!token) return;
    await oc200Client.post('/logout', {}, { headers: { 'Authorization': `Bearer ${token}` } });
    token = null;
  } catch (err) {
    console.error('OC200 Logout Error:', err.message);
  }
};

// --- API Request Wrapper ---
const apiRequest = async (method, url, data = null) => {
  try {
    const authToken = await login();
    const response = await oc200Client({
      method,
      url,
      data,
      headers: { 'Authorization': `Bearer ${authToken}` },
    });
    return response.data.result;
  } catch (err) {
    if (err.response && err.response.status === 401) {
      // Unauthorized, token might be expired. Clear it and retry once.
      token = null;
      const authToken = await login();
      const response = await oc200Client({
        method,
        url,
        data,
        headers: { 'Authorization': `Bearer ${authToken}` },
      });
      return response.data.result;
    }
    throw err; // Rethrow other errors
  }
};


// --- High-Level API Methods ---

export const createVoucher = async (couponCode, plan) => {
  // Assuming the plan object has properties like duration, speed, etc.
  // The payload will depend on the OC200 API's requirements for voucher creation
  const voucherData = {
    code: couponCode,
    duration: plan.duration, // e.g., 24 (hours)
    speed: plan.speed, // e.g., 1024 (kbps)
    // add other necessary plan details here
  };
  return await apiRequest('post', '/create-voucher', voucherData);
};

export const getAccessPoints = async () => {
  return await apiRequest('get', '/aps');
};

export const getActiveSessions = async () => {
  return await apiRequest('get', '/clients'); // Assuming '/clients' gives session info
};

export const disconnectClient = async (mac) => {
  return await apiRequest('post', `/clients/disconnect`, { mac });
};

export const getApLoadInfo = async () => {
  const aps = await getAccessPoints();
  // This is a simplified representation. A real implementation would involve
  // more detailed stats from the controller, possibly from a different endpoint.
  return aps.map(ap => ({
    name: ap.name,
    mac: ap.mac,
    cpuLoad: Math.random() * 100, // Placeholder
    memoryUsage: Math.random() * 100 // Placeholder
  }));
};
